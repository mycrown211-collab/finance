import React, { useState } from 'react';
import { Minus, Calendar, DollarSign, Tag, FileText } from 'lucide-react';
import { useTheme } from './ThemeProvider';
import { formatCurrency } from '../data/mockData';

const ExpenseForm = () => {
  const { isDark } = useTheme();
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().split(' ')[0].slice(0, 5)
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = ['Supplies', 'Transport', 'Maintenance', 'Marketing', 'Utilities', 'Other'];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Reset form
    setFormData({
      amount: '',
      category: '',
      description: '',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().split(' ')[0].slice(0, 5)
    });
    
    setIsSubmitting(false);
    alert('Expense added successfully!');
  };

  const handleAmountChange = (e) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    setFormData({ ...formData, amount: value });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-800'} mb-2`}>
            Add Expense
          </h1>
          <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Track your business expenses and costs
          </p>
        </div>
        <div className={`px-4 py-2 rounded-lg ${isDark ? 'bg-red-500/20 text-red-400' : 'bg-red-100 text-red-600'} flex items-center space-x-2`}>
          <Minus size={16} />
          <span className="font-medium">Expense</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className={`lg:col-span-2 card-3d p-6 rounded-xl ${isDark ? 'glass-effect-dark' : 'glass-effect'}`}>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                  Amount (IDR)
                </label>
                <div className="relative">
                  <DollarSign className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} size={20} />
                  <input
                    type="text"
                    value={formData.amount}
                    onChange={handleAmountChange}
                    placeholder="0"
                    className={`w-full pl-12 pr-4 py-3 rounded-lg form-input-3d ${
                      isDark ? 'text-white placeholder-gray-400' : 'text-gray-800 placeholder-gray-500'
                    } focus:outline-none`}
                    required
                  />
                </div>
                {formData.amount && (
                  <p className={`text-sm mt-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                    {formatCurrency(parseInt(formData.amount) || 0)}
                  </p>
                )}
              </div>

              <div>
                <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                  Category
                </label>
                <div className="relative">
                  <Tag className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} size={20} />
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className={`w-full pl-12 pr-4 py-3 rounded-lg form-input-3d ${
                      isDark ? 'text-white' : 'text-gray-800'
                    } focus:outline-none`}
                    required
                  >
                    <option value="">Select category</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                  Date
                </label>
                <div className="relative">
                  <Calendar className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} size={20} />
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className={`w-full pl-12 pr-4 py-3 rounded-lg form-input-3d ${
                      isDark ? 'text-white' : 'text-gray-800'
                    } focus:outline-none`}
                    required
                  />
                </div>
              </div>

              <div>
                <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                  Time
                </label>
                <input
                  type="time"
                  value={formData.time}
                  onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                  className={`w-full px-4 py-3 rounded-lg form-input-3d ${
                    isDark ? 'text-white' : 'text-gray-800'
                  } focus:outline-none`}
                  required
                />
              </div>
            </div>

            <div>
              <label className={`block text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'} mb-2`}>
                Description
              </label>
              <div className="relative">
                <FileText className={`absolute left-3 top-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} size={20} />
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter description..."
                  rows={4}
                  className={`w-full pl-12 pr-4 py-3 rounded-lg form-input-3d ${
                    isDark ? 'text-white placeholder-gray-400' : 'text-gray-800 placeholder-gray-500'
                  } focus:outline-none resize-none`}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-lg btn-3d flex items-center justify-center space-x-2 disabled:opacity-50 bg-gradient-to-r from-red-400 to-red-600"
            >
              {isSubmitting ? (
                <div className="loading-spinner"></div>
              ) : (
                <>
                  <Minus size={20} />
                  <span>Add Expense</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Summary */}
        <div className="space-y-6">
          <div className={`card-3d p-6 rounded-xl ${isDark ? 'glass-effect-dark' : 'glass-effect'}`}>
            <h3 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-800'} mb-4`}>
              Expense Summary
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Today's Expenses</span>
                <span className={`font-bold text-red-500`}>{formatCurrency(1200000)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>This Week</span>
                <span className={`font-bold text-red-500`}>{formatCurrency(8500000)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>This Month</span>
                <span className={`font-bold text-red-500`}>{formatCurrency(50000000)}</span>
              </div>
            </div>
          </div>

          <div className={`card-3d p-6 rounded-xl ${isDark ? 'glass-effect-dark' : 'glass-effect'}`}>
            <h3 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-800'} mb-4`}>
              Budget Alert
            </h3>
            <div className="space-y-3">
              <div className={`p-3 rounded-lg ${isDark ? 'bg-yellow-500/20 border border-yellow-500/50' : 'bg-yellow-100 border border-yellow-300'}`}>
                <p className={`text-sm ${isDark ? 'text-yellow-400' : 'text-yellow-800'}`}>
                  You've used 68% of your monthly budget
                </p>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '68%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExpenseForm;